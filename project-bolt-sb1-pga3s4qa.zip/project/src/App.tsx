import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import Papa from 'papaparse';

interface CovidData {
  Lat: number;
  Long_: number;
  Deaths?: number;
  Case_Fatality_Ratio?: number;
}

function App() {
  const [data, setData] = useState<CovidData[]>([]);

  useEffect(() => {
    // Load and parse the CSV data
    const csvData = `Lat,Long_,Deaths,Case_Fatality_Ratio
    ${/* Your CSV data here */}`;

    Papa.parse(csvData, {
      header: true,
      dynamicTyping: true,
      complete: (results) => {
        const validData = results.data
          .filter((row: any) => row.Lat && row.Long_)
          .map((row: any) => ({
            Lat: row.Lat,
            Long_: row.Long_,
            Deaths: row.Deaths || 0,
            Case_Fatality_Ratio: row.Case_Fatality_Ratio || 0
          }));
        setData(validData);
      }
    });
  }, []);

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto p-4">
        <h1 className="text-3xl font-bold mb-4">COVID-19 Data Visualization</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="bg-white p-4 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-2">Statistics</h2>
            <p>Total Locations: {data.length}</p>
            <p>Total Deaths: {data.reduce((sum, item) => sum + (item.Deaths || 0), 0)}</p>
            <p>Average Fatality Ratio: {
              (data.reduce((sum, item) => sum + (item.Case_Fatality_Ratio || 0), 0) / data.length).toFixed(2)
            }%</p>
          </div>
        </div>

        <div className="h-[600px] rounded-lg overflow-hidden shadow">
          <MapContainer
            center={[0, 0]}
            zoom={2}
            style={{ height: '100%', width: '100%' }}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
            {data.map((point, index) => (
              <CircleMarker
                key={index}
                center={[point.Lat, point.Long_]}
                radius={Math.max(5, Math.min(20, (point.Deaths || 0) / 100))}
                fillColor="red"
                color="red"
                weight={1}
                opacity={0.5}
                fillOpacity={0.5}
              >
                <Popup>
                  <div>
                    <p>Deaths: {point.Deaths || 'No data'}</p>
                    <p>Fatality Ratio: {point.Case_Fatality_Ratio?.toFixed(2) || 'No data'}%</p>
                  </div>
                </Popup>
              </CircleMarker>
            ))}
          </MapContainer>
        </div>
      </div>
    </div>
  );
}

export default App;