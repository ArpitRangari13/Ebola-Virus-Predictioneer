import pandas as pd
import folium
from folium import plugins

# Read the CSV data
def load_data():
    # Initialize empty lists for data
    lat_long_data = []
    covid_data = []
    
    # Read first CSV (basic coordinates)
    lat_long_df = pd.read_csv('coordinates.csv')
    lat_long_df = lat_long_df.dropna()  # Remove rows with missing values
    
    # Read second CSV (detailed data)
    covid_df = pd.read_csv('covid_data.csv')
    covid_df = covid_df.dropna()  # Remove rows with missing values
    
    return lat_long_df, covid_df

def create_map(covid_df):
    # Create base map centered at [0, 0]
    m = folium.Map(location=[0, 0], zoom_start=2)
    
    # Add markers for each data point
    for idx, row in covid_df.iterrows():
        if pd.notna(row['Lat']) and pd.notna(row['Long_']):
            # Calculate circle radius based on deaths (with min and max limits)
            radius = 5
            if pd.notna(row['Deaths']):
                radius = min(max(5, row['Deaths'] / 100), 20)
            
            # Create popup content
            popup_content = f"""
                Deaths: {row['Deaths'] if pd.notna(row['Deaths']) else 'No data'}<br>
                Fatality Ratio: {row['Case_Fatality_Ratio']:.2f}% if pd.notna(row['Case_Fatality_Ratio']) else 'No data'
            """
            
            # Add circle marker
            folium.CircleMarker(
                location=[row['Lat'], row['Long_']],
                radius=radius,
                popup=popup_content,
                color='red',
                fill=True,
                fillColor='red',
                fillOpacity=0.5,
                weight=1
            ).add_to(m)
    
    return m

def calculate_statistics(covid_df):
    stats = {
        'total_locations': len(covid_df),
        'total_deaths': covid_df['Deaths'].sum(),
        'avg_fatality_ratio': covid_df['Case_Fatality_Ratio'].mean()
    }
    return stats

def main():
    # Load data
    lat_long_df, covid_df = load_data()
    
    # Calculate statistics
    stats = calculate_statistics(covid_df)
    
    # Print statistics
    print("\nCOVID-19 Statistics:")
    print(f"Total Locations: {stats['total_locations']}")
    print(f"Total Deaths: {stats['total_deaths']:,.0f}")
    print(f"Average Fatality Ratio: {stats['avg_fatality_ratio']:.2f}%")
    
    # Create and save map
    m = create_map(covid_df)
    m.save('covid_map.html')
    print("\nMap has been saved as 'covid_map.html'")

if __name__ == "__main__":
    main()